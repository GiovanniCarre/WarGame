Pour créer un type, il faut créer un fichier.et faire la syntaxe suivante dans le fichier:

[nomAutreType] (retour à la ligne)
[Valeurs du coefficient combat] (retour à la ligne)
[nomAutreType2] (retour à la ligne)
[valeurs du coefficient 2]
...
